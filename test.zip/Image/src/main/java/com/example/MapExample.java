package com.example;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class MapExample {

	public static void main(String[] args) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("name", "Ayus");
		map1.put("sirName", "Dwivedi");
		map1.put("age", 12);
		
		NameSirName.Inner nameSirName_Inner = new NameSirName().new Inner();
		nameSirName_Inner.setTest(172);
		map1.put("inner", nameSirName_Inner);
		map1.put("4", "Dwivedi");
		Class<NameSirName> aClass = com.example.NameSirName.class;// obtain
																	// class
																	// object
		Method[] methods = aClass.getMethods();
		Map<String, String> fields = new HashMap<>();
		Map<String, Class<?>> fieldType = new HashMap<>();
		for (int i = 0; i < methods.length; i++) {
			if (methods[i].getName() != null && methods[i].getName().substring(0, 3).compareTo("get") == 0) {
				String tmp = methods[i].getName().substring("get".length());
				System.out.println(tmp.toLowerCase() + "-->" + methods[i].getReturnType().toGenericString());
				fields.put(tmp.toLowerCase(), tmp);
				fieldType.put(tmp.toLowerCase(), methods[i].getReturnType());
			}

		}
		System.out.println(methods.length);

		Object obj = null;

		try {

			obj = aClass.newInstance();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		final Object test = obj;

		Map<String, Object> mappy = map1.entrySet().parallelStream()
				.filter(map -> null != map.getValue() && null != map.getKey())
				.collect(Collectors.toMap(p -> p.getKey(), p -> p.getValue()));
		mappy.entrySet().parallelStream().forEach(map -> {

			String tmp = "";
			if (fields.containsKey(map.getKey().toLowerCase()))
				tmp = fields.get(map.getKey().toLowerCase()).toLowerCase();
			System.out.println(tmp);

			if (map.getKey() != null && map.getKey().toLowerCase().compareTo(tmp) == 0) {
				try {

					Method method = aClass.getDeclaredMethod("set" + fields.get(map.getKey().toLowerCase()),
							fieldType.get(map.getKey().toLowerCase()));
					method.invoke(test, map.getValue());
					System.out.println(test.toString());
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});
		System.out.println(test);

	}

}
