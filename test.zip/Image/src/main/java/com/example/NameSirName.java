package com.example;

public class NameSirName {
	private String name;
	private String sirName;
	private Integer age;
	private Inner inner;
	
	

	public Inner getInner() {
		return inner;
	}

	public void setInner(Inner inner) {
		this.inner = inner;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSirName() {
		return sirName;
	}

	public void setSirName(String sirName) {
		this.sirName = sirName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	

	@Override
	public String toString() {
		return "NameSirName [name=" + name + ", sirName=" + sirName + ", age=" + age + ", inner=" + inner + "]";
	}



	class Inner {
		private int test;

		public int getTest() {
			return test;
		}

		public void setTest(int test) {
			this.test = test;
		}

		@Override
		public String toString() {
			return "Inner [test=" + test + "]";
		}
		
		
		
		
		
		
	}
}
